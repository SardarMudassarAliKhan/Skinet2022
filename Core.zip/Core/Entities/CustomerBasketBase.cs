﻿namespace Skinet.Core.Entities
{
    public class CustomerBasketBase
    {
    }
}